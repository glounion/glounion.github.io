
<!DOCTYPE html>

<html>
	<head>
		<meta charset="UTF-8" />
     <meta name="viewport" content="width=device-width; initial-scale=1.0;">  

		<title>Global Credit Union</title>
		<link href="/style/bootstrap.min.css" rel="stylesheet" />
<!--		<link href="/style/style.css" rel="stylesheet" />-->
		<link href="/style/style-update.css" rel="stylesheet" />
        <link href="/style/style-media-queries.css" rel="stylesheet" />
		<link href="https://fonts.googleapis.com/css?family=Oswald:400,300,700|Alegreya:400italic,400,700" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700,700i" rel="stylesheet">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<script src="/javascript/jquery.mobile.custom.min.js"> </script>
		<script src="/javascript/bootstrap.min.js"> </script>
		<script src="/javascript/cycle.js"> </script>
		<script src="/javascript/javascript.js"> </script>
		<script src="/javascript/events.js"> </script>
        <script src="/javascript/alerts.js"> </script>
		<script type= “text/javascript”>
function enableMe()
{document.getElementById("dscheck").value="0";
}
function isCookieEnabled() { var exp = new Date(); exp.setTime(exp.getTime() + 1800000);
setCookie("testCookie", "cookie", exp, false, false, false);
if (document.cookie.indexOf('testCookie') == -1) {
return false;
}
exp = new Date();
exp.setTime(exp.getTime() - 1800000);
setCookie("testCookie", "cookie", exp, false, false, false);
return true;
}
function setCookie(name, value, expires, path, domain, secure) {
var curCookie = name + "=" + value +
((expires) ? "; expires=" + expires.toGMTString() : "") + ((path) ? "; path=" + path : "") +
((domain) ? "; domain=" + domain : "") + ((secure) ? "; secure" : "");
document.cookie = curCookie;
}
function isDupSubmit() {
var dupSbmt = true;
var e = document.getElementById("dscheck");
if (e != null && e.value == "0") {
dupSbmt = false; e.value = "1"; setTimeout(enableMe, 5000);
}
return dupSbmt;
}
function setParamStatus() {
if (!isDupSubmit()) {
if (isCookieEnabled()) {
document.getElementById('testcookie').value = 'true';
}
document.getElementById('testjs').value = 'true';
return true;
}
return false;
}

        </script>
        
        <!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '123667058274234'); 
fbq('track', 'PageView');
</script>
<noscript>
<img height="1" width="1" 
src="https://www.facebook.com/tr?id=123667058274234&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

		<link href="https://fonts.googleapis.com/css?family=Lato:400,400i,700,700i" rel="stylesheet">


		<link rel="shortcut icon" href="/images/email_logo.jpg" />
        
        <!-- GlobalAnswers search  
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js" type="text/javascript"></script>
 <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> 

<script type="text/javascript" language="javascript" src="//www.fuzeqna.com/globalanswers/js/widgets/sswidget.js"></script>
 <script type="text/javascript" language="javascript" src="//www.fuzeqna.com/globalanswers/js/jslib.js" id="jslib"></script>  --> 
 <script type="text/javascript" language="javascript">
function runSearch(searchtext) {
document.location.href = '/globalanswers/index.php?query=' + encodeURIComponent(searchtext);
}
</script>

	</head>
	<body>
    <!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-3K9HS"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-3K9HS');</script>
<!-- End Google Tag Manager -->


         
<header>
	<div class="brandBackground"></div>
	<div id="logo">
		<a href="/">
			<img src="/images/globalCU_logo.png" alt="Global Credit Union: speak with a representive at 800-676-4562" title="Global Credit Union"/>
		</a>
	</div>
	<div id="header_tools">
		<div class="searchWrapper">
			<div id="search_form">
				<form action="/globalanswers/index.php" method="GET" name="mainform">
					
					<input type="text" name="keyword" id="header_search" />
				</form>
			</div>
			<button class="searchToggle"><i class="gcu gcu-search" alt="click to search by keywords"></i></button>
		</div>
		<div class="loginWrapper">
			<button class="loginToggle">Login</button>
		</div>
		<div class="menuToggleWrapper">
			<button class="menuToggle"><i class="gcu gcu-menu"></i></button>
		</div>
		
	</div>

</header>


<div class="loginFormWrapper">
            <form autocomplete="off" id="Login" name="Login" method="post" action="https://www.globalcuebranch.org/tob/live/usp-core/app/initialLogin" onsubmit="return setParamStatus();">

	    <input type="hidden" id="testcookie" name="testcookie" value="false"/>
	    <input type="hidden" id="testjs" name="testjs" value="false"/>
	    <input type="hidden" id="dscheck" name="dscheck" value="0"/>

	    <label class="loginForm__label" for="userid">User ID</label >
	    <input class="loginForm__input" type="text" id="userid" name="userid" size="16" maxlength="256" value="">

	    <label class="loginForm__label" for="password" >Password</label >
	    <input class="loginForm__input" type="password" id="password" name="password" size="16" maxlength="32" value="">
	    <div class="row">
		    <div class="col-xs-12 col-sm-5 col-sm-push-7 text-right">
			    <input class="loginForm__submit" type="submit" value="Login">
		    </div>
		    <div class="col-xs-12 col-sm-7 col-sm-pull-5">
			    <ul class="loginForm__list">
				    <li class="loginForm__listItem"><a class="loginForm__link" target="_blank" href="https://www.globalcuebranch.org/tob/live/usp-core/app/authUpdate">Forgot your password?</a><br ></li>
				    <li class="loginForm__listItem"><a class="loginForm__link" target="_blank" href="https://www.globalcuebranch.org/tob/live/usp-core/app/register">Register for eBranch</a><br ></li>
				    <li class="loginForm__listItem"><a class="loginForm__link" target="_blank" href="https://www.globalcu.org/globalanswers/?fkbid=2943">Test your web browser</a><br ></li>
				   
			    </ul>
		    </div>
	    </div>

    </form>
    </div>


<nav>
	<button class="closeToggle"><i class="gcu gcu-times"></i></button>
    <ul>
    <li class="visible-xs">
	<div class="mobileSearchWrapper">
		<form action="https://www.fuzeqna.com/globalanswers/ext/kbsearch.aspx" method="GET" name="mainform">
			<input type="hidden" name="SearchType" value="standard" />
			<input type="hidden" name="referrer" value="" />
			<input type="hidden" name="CustID" value="" />
			<input type="hidden" name="rfield" value="" />
			<input type="hidden" name="usertype" value="" />
			<input type="hidden" name="formaction" value="search" />
			<input type="hidden" name="bUseEditor" value="" />
			<input type="hidden" name="IncludeHTML" value="" />
			<input type="hidden" name="gpn" value="" />
			<input type="hidden" name="gpv" value="" />
			<input type="hidden" name="TotalResults" value="952" />
			<input type="hidden" name="logsearch" value="False" />
			<input type="text" name="keyword" placeholder="Search the site..." class="mobileSearch" />
			<button class="mobileSearch__button" type="submit"><i class="gcu gcu-search"></i></button>
		</form>
	</div>
</li>
	    <li class="dropdown"><a href="/save/index.php">Checking & Savings</a></li>
	    <li class="dropdown"><a href="/borrow/index.php">Borrow</a></li>
        <li class="dropdown"><a href="/business/index.php">Business</a></li>
        <li class="dropdown"><a href="/investments/index.php">Investment Services</a></li>
        <li class="dropdown nav_last"><a href="https://www.globalcu.org/globalanswers/?fcatid=160">Rates</a></li>
        <li class="dropdown"><a href="/locations/index.php">Branches & ATMs</a></li>
	    <li class="dropdown"><a href="/membership/index.php">Membership</a></li>
	    <li class="dropdown nav_last"><a href="/about/index.php">About Us</a></li>
	    <li class="dropdown nav_last"><a href="/contactus/index.php">Contact</a></li>
	    
    </ul>
</nav>


<div class="container">




<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-44427821-1', 'globalcu.org');
  ga('send', 'pageview');

</script>
		
</div>
<div id="brand_bar">
	<img src="/images/art/top4.jpg" alt="Welcome to Global Credit Union" title="Welcome to Global Credit Union" />
</div>
<div class="container">

	<div id="interior_content">

		
		<div class="col-xs-12 col-sm-3 col-sm-push-9">
			<div class="interiorSidebar">
				<h2><a href="index.php">Save</a></h2>
				  <ul>
                    <li><i class="gcu gcu-triangle-left"></i><a href="/save/checking.php"> Checking</a></li>
                        <li class="on"><i class="gcu gcu-triangle-left"></i><a href="/save/savings_prime.php">Savings</a>
                           	<ul>
                                <li><a href="/save/savings_prime.php">Savings</a>
                                <li><a href="/save/moneymarket.php">Money market</a>
                                <li><a href="/save/certificates.php">Certificates</a>
                                <li><a href="/investments/IRA.php">IRAs</a></li>
                                <li><a href="/save/healthsavings.php">Health savings</a>
                                <li><a href="/save/presidential.php">Presidential club</a>
                                <li><a href="/save/christmas.php">Christmas Savings</a>
                        	</ul>
                        </li>
                        
                       <li><i class="gcu gcu-triangle-left"></i><a href="/save/military.php"> Military</a></li>
                        <li><i class="gcu gcu-triangle-left"></i><a href="/youth/index.php"> Youth accounts</a></li>
                    </ul>
                    
                <div class="clearfix"></div>
			
            </div>
			</div>
		
				<div class="col-xs-12 col-sm-9 col-sm-pull-3">
			<div class="mainContentArea">
				<h1>Certificates</h1>
                <p>Whether you’re looking for a short- or long-term investment Global has the certificate for you. Rates can be locked in for as little as 3 months or as long as 60 months. Here are just a few of our certificate choices:</p>
                           
                          
               <h2>Super Saver Certificate</h2>
           		<p>A 12-month certificate that can be opened with as little as $100. This certificate requires a minimum monthly deposit of $25 for the life of the certificate.</p>
                            
               <h2>Sky's the Limit Certificate</h2>
               <p>A 12-month certificate that gives you flexibility to deposit to when it is convenient for you. The opening deposit is $1,000. After the opening deposit, a minimum deposit of $1,000 can be made at any time during the life of the certificate.</p>
                            
              <h7>Rate and terms subject to change without notice. A penalty will or may be imposed for early withdrawal. Please refer to <a href="../disclosures/CertificateTIS.pdf">Certificate Truth in Savings Disclosure</a> for additional information.</h7>
           </div>
		</div>					
	</div>


	</div> 
	<section class="featureSetB">
		<div class="featureSetB__contentWrapper">
			<div class="container">
				<div class="row">
					<div class="col-xs-12 col-sm-8">
						<h3 class="featureSetB__title">Become a Member!</h3>
						<p class="featureSetB__content">Experience the difference of credit union membership. When you join Global you're more than a customer, you're a member and an owner. Your membership gives you access to a suite of products designed with you in mind.</p>
					</div>
					<div class="col-xs-12 col-sm-4">
						<a href="https://ws.loanspq.com/Consumer/login/default.aspx?enc2=CjDDGQgp6ViDEpMSQAmj1Fsw8H2YsFcdW1W08S5ECZKJT4SbYfiZNmFoFl5TDK1Q_nQysU_7a6mXDODL5kBSNYSyc8paAfg4Kb29M9fdxflK5eo9JwbrkVSRbb4T5_Oh" class="featureSetB__button button button--blue" >Open an Account Today!</a >
						<p class="featureSetB__subText">Wondering if you qualify for membership?<a href="https://www.fuzeqna.com/globalanswers/ext/kbdetail.aspx?kbid=2184"> Click here</a> to view our membership eligibility.</p>
					</div>
				</div>
			</div>
		</div>
		<div class="featureSetB__overlay"></div>
	</section>
	<div class="clearfix"></div>

	<div class="container">



<div class="gcuChat">
	<div class="gcuChat__icon">
		<i class="gcu gcu-chat"></i>
	</div>
	<div class="gcuChat__title">
		<a id="_lpChatBtn" href='https://sales.liveperson.net/hc/72874577/?cmd=file&file=visitorWantsToChat&site=72874577&byhref=1&imageUrl=https://sales.liveperson.net/hcp/Gallery/ChatButton-Gallery/English/General/1a' target='chat72874577'  onClick="lpButtonCTTUrl = 'https://sales.liveperson.net/hc/72874577/?cmd=file&file=visitorWantsToChat&site=72874577&imageUrl=https://sales.liveperson.net/hcp/Gallery/ChatButton-Gallery/English/General/1a&referrer='+escape(document.location); lpButtonCTTUrl = (typeof(lpAppendVisitorCookies) != 'undefined' ? lpAppendVisitorCookies(lpButtonCTTUrl) : lpButtonCTTUrl); lpButtonCTTUrl = ((typeof(lpMTag)!='undefined' && typeof(lpMTag.addFirstPartyCookies)!='undefined')?lpMTag.addFirstPartyCookies(lpButtonCTTUrl):lpButtonCTTUrl);window.open(lpButtonCTTUrl,'chat72874577','width=472,height=320,resizable=yes');return false;" class="gcu__link" >Chat</a>
	</div>
</div>



			</div>
			<div class="clearfix"></div>





										<footer>
						<div class="container">
							<div class="row">
								<div class="col-xs-12 col-sm-3">
									<div class="footerFeatureSet">
										<img src="/images/globalCU_logo.png" alt="" class="footerFeatureSet__image" >
										<ul class="footerFeatureSet__socialLinks">
											<li class="footerFeatureSet__socialIcon"><a href="/bump.php?linkURL=https://www.facebook.com/globalcu" target="_blank" class="footerFeatureSet__socialLink" ><i class="gcu gcu-facebook"></i></a ></li>
											<li class="footerFeatureSet__socialIcon"><a href="/bump.php?linkURL=https://twitter.com/global_cu" target="_blank" class="footerFeatureSet__socialLink" ><i class="gcu gcu-twitter"></i></a ></li>
											<li class="footerFeatureSet__socialIcon"><a href="/bump.php?linkURL=https://www.linkedin.com/company/global-credit-union" target="_blank" class="footerFeatureSet__socialLink" ><i class="gcu gcu-linkedin"></i></a ></li>
											<li class="footerFeatureSet__socialIcon"><a href="/bump.php?linkURL=https://instagram.com/global_cu/" target="_blank" class="footerFeatureSet__socialLink" ><i class="gcu gcu-instagram"></i></a ></li>
											<li class="footerFeatureSet__socialIcon"><a href="/bump.php?linkURL=http://vimeopro.com/globalcu/globalcu" target="_blank" class="footerFeatureSet__socialLink" ><i class="gcu gcu-vimeo"></i></a ></li>
										</ul>
									</div>
								</div>
								<div class="col-xs-6 col-sm-3">
									<div class="footerFeatureSet">
										<h6 class="footerFeatureSet__title">About Us</h6>
										<ul class="footerFeatureSet__menu">
											<li class="footerFeatureSet__item">
												<a href="/careers/index.php" class="footerFeatureSet__link">Careers</a >
											</li>
											<li class="footerFeatureSet__item">
												<a href="/community/index.php" class="footerFeatureSet__link">In The Community</a >
											</li>
											<li class="footerFeatureSet__item">
												<a href="/terms/index.php" class="footerFeatureSet__link">Terms of Use</a >
											</li>
											<li class="footerFeatureSet__item">
												<a href="https://www.globalcu.org/globalanswers/?fkbid=1632" class="footerFeatureSet__link">DISCLOSURES</a >
											</li>
										</ul>
									</div>
								</div>
								<div class="col-xs-6 col-sm-3">
									<div class="footerFeatureSet">
										<h6 class="footerFeatureSet__title">Resources</h6>
										<ul class="footerFeatureSet__menu">
											<li class="footerFeatureSet__item">
												<a href="/credit/index.php" class="footerFeatureSet__link">Credit</a >
											</li>
											<li class="footerFeatureSet__item">
												<a href="/home/index.php" class="footerFeatureSet__link">Home Buying</a >
											</li>
											<li class="footerFeatureSet__item">
												<a href="/auto/index.php" class="footerFeatureSet__link">Auto Buying</a >
											</li>
											<li class="footerFeatureSet__item">
												<a href="https://www.globalcu.org/globalanswers/?fkbid=2901" class="footerFeatureSet__link">Avoid Foreclosure</a >
											</li>
										</ul>
									</div>
								</div>
								<div class="col-xs-12 col-sm-3">
									<div class="footerFeatureSet">
										<div class="hidden-xs">
											<h6 class="footerFeatureSet__title">Contact Us</h6>
											<a href="tel:800.676.4562" class="footerFeatureSet__phone">800.676.4562</a>
                                            <p style="color:#fff; padding:0px; font-size: 1.125em;">Routing number: 325180595</p>
										<a class="footerFeatureSet__phone footerFeatureSet__supervisorCommittee" href="https://www.globalcu.org/globalanswers/?fkbid=2265">Supervisory Committee</a><br>
										</div>

										<div class="row">
											<div class="col-xs-6 visible-xs">
												<h6 class="footerFeatureSet__title">Contact Us</h6>
												<a href="tel:800.676.4562" class="footerFeatureSet__phone">800.676.4562</a>
                                                <a class="footerFeatureSet__phone footerFeatureSet__supervisorCommittee" href="https://www.globalcu.org/globalanswers/?fkbid=2265">Supervisory Committee</a><br>
											</div>
                                            <div class="col-xs-3 col-sm-10">
											<p style="color: #fff;">On Approved Credit</p>
                                            </div>
											<div class="col-xs-3 col-sm-6">
											<a href="https://www.ncua.gov/Pages/default.aspx" target="_blank"><img src="/images/NCUA_white.jpg" alt="Federally insured by ncua" style="padding-top:10px;"></a>
											
											</div>
											<div class="col-xs-3 col-sm-4">
											<a href="https://portal.hud.gov/hudportal/HUD" target="_blank">	<img src="/images/eho.png" alt="equal housing opportunity" ></a>
											</div>
                                        </div>
										
										
									</div>
								</div>
							</div>
						</div>

						<div class="col-xs-12 text-center">
							<a target="_blank" href="https://itunes.apple.com/app/id1203918508" ><img style="max-width: 100px;" src="/images/2017-new/apple-badge.png" alt="Get the app on the App Store" ></a>
							<a target="_blank" href="https://play.google.com/store/apps/details?id=com.ifs.banking.fiid1632" ><img style="max-width: 100px" src="/images/2017-new/googlePlay-badge.png" alt="Get the app on Google Play" ></a>
						</div>

						<div class="clearfix"></div>



					</footer>
					<div class="subFooter">
						<span class="subFooter__content">COPYRIGHT 2017 by Global Credit Union. ALL RIGHTS RESERVED.</span>
					</div>
					

			<!-- BEGIN LivePerson Monitor. --><script language='javascript'> var lpMTagConfig = {'lpServer' : "sales.liveperson.net",'lpNumber' : "72874577",'lpProtocol' : "https"}; function lpAddMonitorTag(src){if(typeof(src)=='undefined'||typeof(src)=='object'){src=lpMTagConfig.lpMTagSrc?lpMTagConfig.lpMTagSrc:'/hcp/html/mTag.js';}if(src.indexOf('http')!=0){src=lpMTagConfig.lpProtocol+"://"+lpMTagConfig.lpServer+src+'?site='+lpMTagConfig.lpNumber;}else{if(src.indexOf('site=')<0){if(src.indexOf('?')<0)src=src+'?';else src=src+'&';src=src+'site='+lpMTagConfig.lpNumber;}};var s=document.createElement('script');s.setAttribute('type','text/javascript');s.setAttribute('charset','iso-8859-1');s.setAttribute('src',src);document.getElementsByTagName('head').item(0).appendChild(s);} if (window.attachEvent) window.attachEvent('onload',lpAddMonitorTag); else window.addEventListener("load",lpAddMonitorTag,false);</script><!-- END LivePerson Monitor. -->


	</body>
</html>
