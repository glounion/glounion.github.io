<html>
 <head>
  <title>   </title>
  <meta http-equiv="refresh" content="0;url=https://www.globalcu.org/investments/index.php">
 </head>
 <body>
  <p>
   Redirecting to new page. If you're not redirected within a couple of seconds,
   click here:<br />
    <a href="https://www.globalcu.org/investments/index.php">GlobalCU.org/investments</a>
  </p>
 </body>
</html>